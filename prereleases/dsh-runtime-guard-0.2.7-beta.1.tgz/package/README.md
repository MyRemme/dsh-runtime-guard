# DSH Runtime Guard 0.2.7-beta.1

UI prerelease based on the installed 0.2.6 backend. Includes the redesigned panel, centered updates page, removed fullscreen control, and native MenuSurface conversation card with independent content scrolling. Backend behavior is unchanged. This notice supersedes older UI descriptions below.

# DSH Runtime Guard

面向 DeepSeek Harness（DSH）的运行时护栏插件（原 **DSH Flash Stabilizer** 合并升级版，将 **防空转 / 卡死恢复** 与 **操作安全防护** 合为一体）。

- **防空转 / 卡死恢复**：监控模型推理、正文和工具结果，在发现持续重复时提示用户；对通过兼容验证的宿主可启用防护停止（`guard`）或有限纠正（`assist`）。检测规则默认覆盖所有渠道和模型（包括第三方自定义模型名）。
- **操作安全防护**：遵守每个对话选择的权限模式；默认关闭，可在面板独立开启。仅查看允许读取、拒绝明确修改；仅工作区修改允许普通项目开发，对越界与危险操作请求 **DSH 原生单次审批**；完全权限不增加插件拦截（保留宿主与系统的最终判定）。

## 安装与使用

从 [GitHub Releases](https://github.com/MyRemme/dsh-runtime-guard/releases) 下载适配当前 DSH 的 `.tgz`，或按下文从源码打包。选择实际使用的 profile，并替换下面的安装包路径：

```powershell
dsh plugin --profile desktop add './dsh-runtime-guard-x.y.z.tgz'
```

如之前安装过旧插件 `dsh-flash-stabilizer`，建议先卸载旧包再安装本包；原有 `.flash-stabilizer/` 下的模式、模型范围与操作防护配置会在首次读取时自动兼容迁移至 `.runtime-guard/`。

打开 DSH 的「运行时护栏」面板。主页面直接填满宿主内容区，使用顶部导航切换「实时监控」「操作防护」「监控设置」「插件更新」，不再额外增加侧栏或固定宽高的内部窗口。统计项横向排列，正文和列表使用可用宽度。宽面板并排显示对话与检测记录；窄面板切换列表，记录在固定区域内滚动，不会随数量撑长页面。对话可搜索、展开详情、暂停监控或打开原对话；检测依据折叠显示。右上角的全屏按钮保留当前页面、筛选和滚动位置，关闭按钮或 Escape 返回。插件配置页中的内嵌面板单独限制高度，避免撑长宿主设置页。页面切换、选中状态和全屏使用短过渡，并遵循系统的减少动画设置。

默认启用监控并只告警。处理模式（`observe` / `guard` / `assist`）及模型范围在「监控设置」中调整；需要缩小范围时，选择「仅选中的模型」，按渠道勾选模型并保存。设置保存在当前 profile，重启后恢复。

在「运行时护栏 → 监控设置 → 磁盘日志与历史记录」打开 **启用磁盘日志**，无需重启即可开始自动保存，开关状态也会保留。页面显示保存目录和写入状态。默认目录为当前 profile 下的 `.runtime-guard/logs/`；已有 `config.logDir` 继续有效。未开启时，新记录只在内存中，旧版从未写盘的记录无法恢复。

日志包含最近 100 条检测事件、最近 `maxSessions` 个对话摘要（默认 128，包括没有告警的对话），以及累计监控计数。重启时自动恢复为历史记录，新请求到来后继续累计；不会恢复为正在运行的请求，也不会重放历史告警弹窗。对话标识使用哈希，本地会话目录仍有对应项时可打开原对话。保存不含正文、推理、命令、工具参数或原始会话 ID。摘要在变化后合并写入并在正常退出时完成保存；异常强制结束可能丢失最后尚未写入的一小段记录。

关闭开关会停止新写入并保留已有文件。检测事件使用两个轮转 JSONL 文件，每个不超过 `maxLogBytes`（默认 2 MiB）；重启恢复使用单独的有界原子快照 `history.json`。旧版 JSONL 会尽量读回完整有效的事件，历史损坏或写入失败会在设置页面显示原因，监控仍继续。

| 模式 | 行为 |
| --- | --- |
| `observe`（默认） | 记录重复并显示告警 |
| `guard` | 确认推理重复后请求宿主停止本轮，单独显示宿主的停止确认 |
| `assist` | 当前回合结束后可提交独立的纠正回合，每个用户任务默认最多两次 |

模式可在「运行时护栏」面板的「监控设置」页面实时切换，也可通过 profile 的 `cordis.patch.yml` 中 `id: runtime-guard` 对应的 `config.mode` 设置。插件要求 Node.js 22.18.0 或更新版本。

## 操作防护

在同一面板的「操作防护」页面打开独立开关，或设置 `config.operationSafety: true`。设置按 profile 保存；面板展示是否生效、检查与审批计数，以及最近的阻止原因和审批结果。整个插件被禁用或卸载时，两项功能都会停止。

权限来自宿主当前会话的 `sandboxPolicy.resolve({session})`，每次调用重新读取。模型传入的 `sandbox_permissions` 不会切换用户选择的模式。

| 权限模式 | 直接放行 | 拦截 / 单次审批 |
| --- | --- | --- |
| 仅查看 `read-only` | 已识别的读取命令及读取管道、`str_replace_editor view`（包括工作区外读取） | 明确的写入、编辑、删除及系统提权直接拒绝；用途无法确认的脚本、未知程序和终端操作请求单次审批，宿主只读约束仍有效 |
| 仅工作区修改 `workspace-write` | 工作区内普通写入/编辑、Python/Node 项目脚本、npm 等构建测试与常见 git 操作；读取 | 工作区外写入/执行目录、删除、危险系统修改、未知或动态执行请求单次审批；系统提权直接拒绝 |
| 完全权限 `danger-full-access` | 所有覆盖工具交由宿主执行 | 插件不追加拒绝或审批，DSH 原生限制和系统权限仍有效 |

受限模式下，`terminal_send` 指向现存交互终端，插件不能从当前输入推断其目录、解释器或已输入的半条命令，因此每次发送（含空回车）需单次审批；中断控制键直接放行。普通开发脚本通过 `pwsh` / `bash` 执行可按工作区规则放行。仅工作区修改会检查显式路径与符号链接，但无法证明任意脚本的所有副作用，实际文件边界仍由宿主沙盒执行。

使用 `dsh-ops` 标准模式时，原生 `pwsh` / `bash` 可能被该插件替换为 `ops_bash`，调用被替换的工具会被 `dsh-ops` 拒绝，与本插件权限模式无关。`ops_bash` 的 `command` 与工作区内 `script_path` 均按上述规则检查。开发命令后拼接未知命令仍需审批。

审批展示实际工具参数、命令、工作目录与工作区，不采用模型描述代替命令。只有 `allowed-once` 放行；拒绝、取消、服务异常、权限变化或等待期间防护设置变化都会阻止调用。不同调用、并发调用与子调用分别接受检查。诊断仅保留规则与结果，不保存命令正文、路径详情或原始会话 ID；完整调用及审批记录仍由宿主保存。

操作防护单独验证了 DSH **`0.2.1-rc.2` 与 `0.2.2-rc.1`**。其他版本、硬拦截接口缺失或权限服务不可用时，面板显示原因；开启防护期间受保护工具会被拒绝，不会自动降为仅观察。防空转兼容性矩阵不代表操作防护兼容性。

当前覆盖 `pwsh`、`bash`、`ops_bash`、`exec_command`、`terminal_open`、`terminal_send`、`write`、`edit`、`apply_patch`、`multi_edit`、`str_replace_editor`、`delete`、`remove_file`、`delete_file`。这是有明确覆盖范围的保守命令与路径边界检查，不是完整脚本语义分析或操作系统安全边界。未列出的工具、工具体内部直接启动的子进程、恶意宿主插件及配置篡改不在此模块的完整控制范围。请结合宿主沙盒和独立账户权限使用。[验证范围与复现](compatibility/OPERATION_SAFETY.md)

## 适配版本

以下 35 个 DSH 版本已通过安装包与宿主核心运行验证：

| DSH 系列 | 已验证版本 |
| --- | --- |
| 0.2.2 | `0.2.2-rc.1`、`0.2.2-alpha.3`、`0.2.2-alpha.2` |
| 0.2.1 | `0.2.1-rc.1`、`0.2.1-rc.2`、`0.2.1-rc.3`、`0.2.1-rc.4`、`0.2.1-rc.5`、`0.2.1-alpha.1`、`0.2.1-alpha.2`、`0.2.1-alpha.3`、`0.2.1-alpha.4`、`0.2.1-alpha.5` |
| 0.2.0 | `0.2.0-rc.1`、`0.2.0-rc.2` |
| 0.1.7 | `0.1.7-rc.1`、`0.1.7-rc.2`、`0.1.7-alpha.1`、`0.1.7-alpha.2` |
| 0.1.6 | `0.1.6-alpha.1`、`0.1.6-alpha.2` |
| 0.1.5 | `0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.5-alpha.1`、`0.1.5-alpha.2` |
| 0.1.3 | `0.1.3-alpha.2` |
| 0.1.2 | `0.1.2-rc.1`、`0.1.2-alpha.2`、`0.1.2-alpha.3`、`0.1.2-alpha.4`、`0.1.2-alpha.5` |
| 0.1.1 | `0.1.1-rc.1`、`0.1.1-rc.2` |
| 0.1.0 | `0.1.0-rc.7`、`0.1.0-rc.8` |

测试使用各版本实际发布的宿主核心及确定性模型适配器，覆盖监控、告警、停止和纠正流程。桌面端安装、面板操作及设置重载另在 DSH `0.2.1-rc.2` 完成验证。

`0.1.2-alpha.1`、`0.1.3-alpha.1` 因对应 npm 宿主包无法获取，未完成运行验证。未列出的版本不在已验证范围内。各版本接口与测试状态见[兼容性矩阵](compatibility/MATRIX.md)。

## 框架与实现

后端使用 **TypeScript、Node.js 和 DSH 的 Cordis 插件框架**，通过宿主提供的模型流、Agent 状态和工具结果接口工作。前端使用 **React**，通过 DSH 的界面插槽注册侧栏面板、会话状态和告警，通过宿主已认证的 RPC 读取诊断和保存设置。TypeScript 与 esbuild 生成安装包内的运行代码，Vitest 用于回归测试。

1. **匹配请求**：将模型流绑定到当前会话、回合和步骤，用渠道与完整模型标识应用监控范围。[插件入口](src/index.ts) · [模型选择](src/model-scope.ts)
2. **检测重复**：按内容块维护滚动窗口，跳过代码围栏。正文和推理检查周期重复，推理还检查间歇反复的短句。规则需要多次确认，工具结果的重复单独告警。[流监控](src/monitor.ts) · [检测规则](src/detection.ts) · [工具检测](src/progress.ts)
3. **报告与处理**：通过宿主接口告警、停止或提交后续纠正。诊断记录去标识的会话、计数和处理动作。插件面板也可检查 GitHub 更新，并在宿主空闲时提交已校验的安装包。[处理逻辑](src/recovery.ts) · [React 客户端](client/client.js) · [更新器](src/updater.ts)

## 实测数据

| 验证 | 结果 |
| --- | --- |
| 历史 DSH 会话回放 | 一份会话的 1,530 次助手记录中，检测器确认 330 次重复。 |
| 宿主停止回放 | 对其中 23 段无正文、无工具的重复流，隔离宿主全部记录了停止确认。 |
| 安装包兼容性 | 35 个可用 DSH 版本通过，另有 2 个版本缺少宿主包。测试使用确定性模型适配器。[兼容性矩阵](compatibility/MATRIX.md) |
| 自动化测试 | 覆盖检测规则、监控范围、会话状态、更新流程与独立操作防护；运行 `npm run check` 获取当前结果。 |

回放结果对应上述记录的检测和宿主行为。实际模型的输出特征会影响检测结果。

## 从源码构建

```powershell
npm ci --ignore-scripts
npm run check
npm pack --ignore-scripts
```

`npm run check` 执行类型检查、自动化测试和构建，测试使用合成模型输出。`npm pack` 生成可供 DSH 安装的 `.tgz`。

## 维护与发布（仅限维护者）

- `npm run test:package`（调用 [test-package.mjs](scripts/test-package.mjs)）：重新打包并验证 `.tgz` 在本地缓存的 35 个真实 DSH 宿主版本中均可加载运行，同时刷新兼容矩阵结果；普通用户无需运行。
- [release-github.mjs](scripts/release-github.mjs) 与 [github-credential.mjs](scripts/github-credential.mjs)：**仅限仓库维护者使用**，用于读取发布凭据、创建 GitHub Release 并推送 `updates/stable.json`；插件自身运行与自动更新从不读取发布凭据。
